"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";

const containerVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: "easeOut", staggerChildren: 0.12 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

export default function HeroDark() {
  return (
    <section className="relative h-[75vh] md:h-[85vh] w-full overflow-hidden bg-slate-950">

      {/* Hintergrund + Zoom/Pan */}
      <Image
        src="/hero/mn-glanzwerk-hero.webp"
        alt="Gereinigter moderner Innenraum"
        fill
        priority
        sizes="100vw"
        className="object-cover opacity-45 hero-zoom-pan"
      />

      {/* Gradient für bessere Lesbarkeit */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/70 to-slate-950/75" />

      {/* Inhalt */}
      <motion.div
        className="relative z-10 flex h-full flex-col items-center justify-center px-4 md:px-6 text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Badge */}
        <motion.p
          variants={itemVariants}
          className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 
          text-[10px] md:text-[11px] font-semibold uppercase tracking-[0.18em] text-sky-100"
        >
          <span className="h-4 w-4 md:h-5 md:w-5 rounded-full bg-brand/80" />
          <span className="leading-none">MN GLANZWERK CLEANING COMPANY</span>
        </motion.p>

        {/* Haupttitel */}
        <motion.h1
          variants={itemVariants}
          className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-3xl"
        >
          Professionelle Gebäudereinigung
          <span className="block text-brand mt-1">
            für höchste Ansprüche
          </span>
        </motion.h1>

        {/* Untertitel */}
        <motion.p
          variants={itemVariants}
          className="mt-4 max-w-lg text-slate-200 text-sm md:text-base leading-relaxed"
        >
          Sauberkeit auf Premium-Niveau für Privat- und Geschäftskunden
          in Schleswig-Holstein, Hamburg &amp; Bremen – zuverlässig, gründlich & diskret.
        </motion.p>

        {/* Buttons */}
        <motion.div
          variants={itemVariants}
          className="mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4"
        >
          <Link
            href="/contact"
            className="rounded-full bg-brand px-7 py-3 text-sm md:text-base font-semibold text-white 
            shadow-xl shadow-brand/30 hover:bg-brand-soft transition-all"
          >
            Angebot anfordern
          </Link>

          <a
            href="tel:+491637885512"
            className="rounded-full border border-slate-500/60 bg-slate-900/70 px-7 py-3 
            text-sm md:text-base font-semibold text-slate-200 hover:bg-slate-800 transition"
          >
            Jetzt anrufen: 0163&nbsp;7885512
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
}
